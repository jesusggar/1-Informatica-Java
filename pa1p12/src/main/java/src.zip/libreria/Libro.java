package libreria;

public class Libro {
    private static double porcIVA = 10.0;
    private String autor;
    private String titulo;
    private double precioBase;
    public Libro(String autorL, String tituloL, double precioL){
        autor = autorL;
        titulo = tituloL;
        precioBase = precioL;
    }

    public String getAutor() {
        return autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    protected double getBaseImponible() {  // @Protegido
        return precioBase;
    }

    public double getPrecioFinal() {
        return this.getBaseImponible()+(this.getBaseImponible()*(porcIVA/100));
    }

    @Override
    public String toString() {
        return "("+this.autor+"; "+this.titulo+"; "+this.precioBase+"; "+porcIVA+"%; "+this.getPrecioFinal()+")";
    }

    public static double getIVA() {
        return porcIVA;
    }

    public static void setIVA(double IVA) {
        porcIVA = IVA;
    }
}
