package datos;

public class DatosException extends RuntimeException{
    public DatosException() {
        super();
    }
    public DatosException(String datos) {
        super(datos);
    }
}
