package datos2;

public class DatosException extends Exception{
    public DatosException() {
        super();
    }
    public DatosException(String datos) {
        super(datos);
    }
}
