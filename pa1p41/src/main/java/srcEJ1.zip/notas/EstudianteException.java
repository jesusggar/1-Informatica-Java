package notas;

public class EstudianteException extends Exception{
    public EstudianteException() {
        super();
    }
    public EstudianteException(String s) {
        super(s);
    }
}
